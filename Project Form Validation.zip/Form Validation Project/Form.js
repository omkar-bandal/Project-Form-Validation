const form = document.querySelector('.form');
const allinputs = document.querySelectorAll('input');
const iname = document.getElementById('iname');
const mobileno = document.getElementById('MobileNo');
const age = document.getElementById('Age');
const eriname = document.getElementById('er-name');
const ermob = document.getElementById('er-mob');
const erage = document.getElementById('er-age');
const ersubmit = document.getElementById('er-submit');
let valid = true;
iname.addEventListener('input', function () {
    if (iname.value.length < 3) {
        iname.style.border = '1px solid red';
        eriname.textContent = '*Invalid name';
        valid = false;
    }
    else {
        iname.style.border = '1px solid black';
        eriname.textContent = '';
        valid = true;
    }
});

mobileno.addEventListener('input', function () {
    if (mobileno.value.length < 10 || mobileno.value.length > 10) {
        mobileno.style.border = '1px solid red';
        ermob.textContent = '*Invalid Mobile Number';
        valid = false;
    }
    else {
        mobileno.style.border = '1px solid black';
        ermob.textContent = '';
        valid = true;
    }
});
age.addEventListener('input', function () {
    if (age.value < 0) {
        age.style.border = '1px solid red';
        erage.textContent = '*Invalid Age';
        valid = false;
    }
    else {
        age.style.border = '1px solid black';
        erage.textContent = '';
        valid = true;
    }
});
form.addEventListener('onsubmit', function (event) {
    if (valid == false) {
        event.preventDefault();
        ersubmit.textContent = '*Please fill complete and correct form fields';
    }
});